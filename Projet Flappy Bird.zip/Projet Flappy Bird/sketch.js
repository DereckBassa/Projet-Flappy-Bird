//Projet Final par Dereck Bassa

var bird;
var pipes = [];
var dead = false;
var over = false;
var points = 0;
var score = 0;
var GameOver = false;
var fini = false;


function Pipe() {  
//La longeur de l'objet 'Pipe' est déterminée par un nombre choisi au hasard par l'ordinateur
  this.top= random(height/2);
  this.bottom = random(height/2);
  this.x = width;
  this.w = 60;
  this.speed = 5;
  
  this.highlights = false;
  
  this.hits = function(bird) {
//Quand l'oiseau touche l'objet 'Pipe', l'oiseau meurt et le jeu s'arrête
    if (bird.y < this.top || bird.y > height - this.bottom) {
      if (bird.x > this.x && bird.x < this.x + this.w) {
        this.highlight = true;
        dead = true;
        over = true;
        GameOver = true;
        bird.lift = 0;
        return true;
      }
    }
    this.highlight = false;
    return false;
  }
  
  
  this.show = function() {
    fill(121, 192, 0);
    
//Quand l'oiseau touche l'objet 'Pipe', l'objet devient rouge 
    if (this.highlight) {
      fill(255, 0, 0);
    }
    rect (this.x, 0, this.w, this.top);
    rect(this.x, height-this.bottom, this.w, this.bottom);
  }
  
  this.update = function() {
    if (dead === false) {
      this.x -= this.speed;
    }
//À chaque 10 points, la vitesse des pipes augmente par 1
    if (score >= 10 && score <= 20) {
      this.speed = 6;
    }
    if (score >= 20 && score <= 30) {
      this.speed = 7;
    }
    if (score >= 30 && score <= 40) {
      this.speed = 8;
    }
    if (score >= 40 && score <= 50) {
      this.speed = 9;
    }
    if (score >= 50 && score <= 60) {
      this.speed = 10;
    }
    if (score >= 60 && score <= 70) {
      this.speed = 11;
    }
    if (score >= 70 && score <= 80) {
      this.speed = 12;
    }
    if (score >= 80 && score <= 90) {
      this.speed = 13;
    }
    if (score >= 90 && score <= 100) {
      this.speed = 14;
    }
    if (score >= 100) {
      this.speed = 15;
    }
  }
  
  this.offscreen = function() {
    if (this.x < -this.w) {
      return true;
    }
    else {
      return false;
    }
  }
}
function Bird() {
  this.y = height/2;
  this.x = 64;
  
  this.gravity = 0.64;
  this.lift = -15;
  this.velocity = 0;
  
  this.show = function() {
    fill(255, 204, 0);
    ellipse(this.x, this.y, 32, 32);
  }
  
  this.up = function() {
    this.velocity += this.lift;
  }
  
  this.update = function() {
    this.velocity += this.gravity;
    this.velocity *= 0.9;
    this.y += this.velocity;
    
    if (this.y > height) {   
      this.y = height;
      this.velocity = 0;
    }
    
    if (this.y < 0) {
      this.y= 0;
      this.velocity = 0;
    }
  }
  
}

function setup() {
//Les dimensions de la fenêtre sont determinées
  createCanvas(400, 600);
  bird = new Bird();
  pipes.push(new Pipe());
}

function draw() {
  background(112, 197, 206);
  textAlign(CENTER);
  textSize(60);
  text
  text(score, 200,150);
//Si le jeu s'arrête, ce texte apparait et dit d'appuyer '7' pour continuer
  if (GameOver === true) {
  textAlign(CENTER);
  textSize(28);
  text("Appuie 7 pour recommencer", 200, 300);
  }
  
  for (var i = pipes.length-1; i>=0; i--) {
    pipes[i].show();
    pipes[i].update();
    
    if (pipes[i].hits(bird)) {
    }
    
    if (pipes[i].offscreen()) {
      pipes.splice(i,1);   
    }
    
  }
  bird.update();
  bird.show();

// À chaque 50 images, un nouvel objet 'Pipe' est crée
  if (frameCount % 50 === 0) {
    pipes.push(new Pipe());
  }
}


// À chaque fois que ' ' est appuyé l'objet "bird" monte
function keyPressed() {
  if (key == ' ' && dead === false) {
   bird.up();
   score += 1;
  }
// Si l'oiseau est mort et le boutton '7' est appuyé, le jeu recommence
  if (key == '7' && dead === true && GameOver === true) {
   location.reload(true);
  }

}


